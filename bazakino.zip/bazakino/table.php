<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<?php

$host = "localhost"; $username = "root"; $password = ""; $database = "4ti1_kino";

$connect =  mysqli_connect($host, $username, $password, $database);

if (mysqli_connect_error()) {

    echo "<p>Connection failed.</p>";
    exit();

} // else { echo "<p>Successfully connected.</p>"; } //

$query = "SELECT filmy.id as ID, tytul, rezyser, czas_trwania FROM filmy";

if ($result = mysqli_query($connect, $query)) {

    echo "<div class='table'>";
    echo "<table>";
    echo "<tr><th>ID</th><th>tytuł</th><th>reżyser</th><th>czas trwania</th></tr>";

    foreach (mysqli_fetch_all (result: $result) as $row) {

        echo "<tr><td>" . $row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td><td>" . $row[3] . "</td>";

    }

    echo "</table>";
    echo "</div>";

}

mysqli_close($connect);

?>

</body>
</html>
