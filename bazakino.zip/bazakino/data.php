<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <fieldset>

        <legend>Filmy</legend>

        <form method="POST">

            <label for="title">Tytuł:</label>
            <input type="text" id="title" name="title" required><br>

            <label for="director">Reżyser:</label>
            <input type="text" id="director" name="director" required><br>

            <label for="time">Czas trwania:</label>
            <input type="time" step="1" id="time" name="time" required>

            <button type="submit">Dodaj</button>

        </form>

    </fieldset><br>

<?php

$host = "localhost"; $username = "root"; $password = ""; $database = "4ti1_kino";

$connect =  mysqli_connect($host, $username, $password, $database);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $connect -> real_escape_string($_POST['title']);
    $director = $connect -> real_escape_string($_POST['director']);
    $time = $connect -> real_escape_string($_POST['time']);

    $id = $connect -> query("SELECT MAX(ID) AS max FROM filmy");

    if ($id -> num_rows > 0) {

        $a = $id -> fetch_assoc();
        $id = $a['max'] + 1;

    } else { echo "Wystąpił błąd."; }

    $sql = "INSERT INTO filmy (ID, tytul, rezyser, czas_trwania) VALUES ('$id', '$title', '$director', '$time')";

    if ($connect -> query($sql) === TRUE) {

        header("Location: data.php?status=success");
        exit;

    } else { echo "Błąd: " . $sql . "<br>" . $connect -> error; }

}

mysqli_close($connect);

?>

</body>
</html>