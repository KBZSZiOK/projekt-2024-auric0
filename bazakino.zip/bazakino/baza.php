<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>baza</title>
</head>
<body>

    <header>

        <div id="logo">

            <img src="logo.png">

        </div>
                  
        <div id="przyciski">

            <a href="link1.html">Link1</a>
            <a href="link1.html">Link2</a>
            <a href="link1.html">Link3</a>
            <a href="link1.html">Link4</a>

        </div>

    </header>

    <footer>

        &copy 2024

    </footer>

    <?php

    $host = "localhost"; $username = "root"; $password = ""; $database = "4ti1_kino";

    $connect =  mysqli_connect($host, $username, $password, $database);

    if (mysqli_connect_error()) {

        echo "<p>Connection failed.</p>";
        exit();

    } // else { echo "<p>Successfully connected.</p>"; } //

    $query = "SELECT filmy.id as ID, tytul, rezyser, czas_trwania FROM filmy";

    if ($result = mysqli_query($connect, $query)) {

        echo "<table>";
        echo "<tr><th>ID</th><th>tytuł</th><th>reżyser</th><th>czas trwania</th></tr>";

        foreach (mysqli_fetch_all (result: $result) as $row) {

            echo "<tr><td>" . $row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td><td>" . $row[3] . "</td>";

        }

        echo "</table>";

    }

    mysqli_close($connect);
    ?>
    
</body>
</html>