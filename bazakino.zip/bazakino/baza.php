<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>baza</title>
</head>
<body>

    <header>

        <div id="logo">

            <img src="logo.png">

        </div>
                  
        <div id="przyciski">

            <a href="link1.html">Link1</a>
            <a href="link1.html">Link2</a>
            <a href="link1.html">Link3</a>
            <a href="link1.html">Link4</a>

        </div>

    </header>

    <div class="container">

        <h1>Dodaj filmy</h1>
        <form method="POST">

            <label for="title">Tytuł:</label>
            <input type="text" id="title" name="title" required><br>

            <label for="director">Reżyser:</label>
            <input type="text" id="director" name="director" required><br>

            <label for="time">Czas trwania:</label>
            <input type="time" step="1" id="time" name="time" required><br><br>

            <button type="submit">Dodaj</button>

        </form>

    </div>

    <footer>

        &copy 2024

    </footer>

    <?php

    $host = "localhost"; $username = "root"; $password = ""; $database = "4ti1_kino";

    $connect =  mysqli_connect($host, $username, $password, $database);

    if (mysqli_connect_error()) {

        echo "<p>Connection failed.</p>";
        exit();

    } // else { echo "<p>Successfully connected.</p>"; } //

    $query = "SELECT filmy.id as ID, tytul, rezyser, czas_trwania FROM filmy";

    if ($result = mysqli_query($connect, $query)) {

        echo "<table>";
        echo "<tr><th>ID</th><th>tytuł</th><th>reżyser</th><th>czas trwania</th></tr>";

        foreach (mysqli_fetch_all (result: $result) as $row) {

            echo "<tr><td>" . $row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td><td>" . $row[3] . "</td>";

        }

        echo "</table>";

    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $title = $connect -> real_escape_string($_POST['title']);
        $director = $connect -> real_escape_string($_POST['director']);
        $time = $connect -> real_escape_string($_POST['time']);

        $sql = "INSERT INTO filmy (tytul, rezyser, czas_trwania) VALUES ('$title', '$director', '$time')";

        if ($connect -> query($sql) === TRUE) {

            header("Location: baza.php?status=success");
            exit;

        } else {

            echo "Błąd: " . $sql . "<br>" . $connect -> error;

        }

    }

    mysqli_close($connect);

    ?>

</body>
</html>