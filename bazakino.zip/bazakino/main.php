<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <h2>Witaj na stronie bazy danych kina!</h2>
    <p>Tu będziesz w stanie dodawać oraz odczytywać dane z tabel (na razie tylko jednej) dostępnych w bazie danych kina przy użyciu formularzy PHP.</p>
    <p>W zakładce "O stronie" do pobrania jest dostępny plik z zapytaniami SQL tworzącymi bazę danych oraz dane w niej zawarte (nwm po co ale może kiedyś na coś się przyda).
    <p>Proszę nie kwestionować loga strony, autor nie miał pomysłu co na nie dać.</p>
    <p>To tyle.</p>

</body>
</html>
