<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="iframe-container">
        
        <a href="zapytania_kino.sql" download="kino_zapytania.sql" id="link-dl">Pobierz plik z zapytaniami SQL</a>

    </div>

</body>
</html>